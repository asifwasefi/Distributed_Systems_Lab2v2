package be.uantwerpen.RESTbanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResTbankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResTbankingApplication.class, args);
	}

}
