package be.uantwerpen.RESTbanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResTbankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
